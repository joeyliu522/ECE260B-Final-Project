## Tcl for skew_group
# Skew Group Mode: all
switch_ccopt_skew_group_mode -create all
# Skew Group: all
create_ccopt_skew_group -name all -generated  -auto_sinks -sources {{clk rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: default
switch_ccopt_skew_group_mode -create default
# Skew Group: clk/CON
create_ccopt_skew_group -name clk/CON -from_clock clk -from_constraint_modes {CON} -from_delay_corners {WC BC} -auto_sinks -sources {clk}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: fragment
switch_ccopt_skew_group_mode -create fragment
# Skew Group: 1
create_ccopt_skew_group -name 1 -generated  -fragment  -target_insertion_delay 0.081 -target_skew 0.001 -sinks {core_instance2/clk core_instance1/clk} -rank 0 -sources {{clk rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: icts
switch_ccopt_skew_group_mode -create icts
# Skew Group: clk/CON
create_ccopt_skew_group -name clk/CON -auto_sinks -sources {clk}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group

# Switch back to default mode.
switch_ccopt_skew_group_mode default